library(testthat)
library(rticles)

test_check("rticles")
