#* @serializer html
#* @get /
function(){
  "<html>Test here</html>"
}
