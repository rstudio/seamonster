#* @assets ./files/static static
list()

#* @assets files/static /static
list()

#*@assets ./files/static
list()

#* @assets files/static
function(){

}
