context("Plumber")

test_that("Endpoints are properly identified", {
  r <- plumber$new("files/endpoints.R")
  expect_equal(length(r$endpoints), 1)
  expect_equal(length(r$endpoints[[1]]), 4)
  expect_equal(r$endpoints[[1]][[1]]$exec(), 5)
  expect_equal(r$endpoints[[1]][[2]]$exec(), 10)
  expect_equal(r$endpoints[[1]][[3]]$exec(), 12)
  expect_equal(r$endpoints[[1]][[4]]$exec(), 14)
})

test_that("Empty file is OK", {
  r <- plumber$new()
  expect_equal(length(r$endpoints), 0)
})

test_that("The file is sourced in the envir", {
  r <- plumber$new("files/in-env.R")
  expect_equal(length(r$endpoints), 1)
  expect_equal(length(r$endpoints[[1]]), 2)
  expect_equal(r$endpoints[[1]][[1]]$exec(), 15)
})

test_that("Verbs translate correctly", {
  r <- plumber$new("files/verbs.R")
  expect_equal(length(r$endpoints), 1)
  expect_equal(length(r$endpoints[[1]]), 7)
  expect_equal(r$endpoints[[1]][[1]]$verbs, c("GET", "PUT", "POST", "DELETE", "HEAD"))
  expect_equal(r$endpoints[[1]][[2]]$verbs, "GET")
  expect_equal(r$endpoints[[1]][[3]]$verbs, "PUT")
  expect_equal(r$endpoints[[1]][[4]]$verbs, "POST")
  expect_equal(r$endpoints[[1]][[5]]$verbs, "DELETE")
  expect_equal(r$endpoints[[1]][[6]]$verbs, c("POST", "GET"))
  expect_equal(r$endpoints[[1]][[7]]$verbs, "HEAD")
})

test_that("Invalid file fails gracefully", {
  expect_error(plumber$new("asdfsadf"), regexp="File does not exist.*asdfsadf")
})

test_that("plumb accepts a file", {
  r <- plumb("files/endpoints.R")
  expect_length(r$endpoints[[1]], 4)
})

test_that("plumb accepts a directory with a `plumber.R` file", {
  # works without trailing slash
  r <- plumb(dir = 'files')
  expect_equal(length(r$endpoints), 1)
  expect_equal(length(r$endpoints[[1]]), 4)

  # works with trailing slash
  r <- plumb(dir = 'files/')
  expect_equal(length(r$endpoints), 1)
  expect_equal(length(r$endpoints[[1]]), 4)

  # errors when no plumber.R found
  expect_error(plumb(dir = 'files/static'), regexp="File does not exist: files/static/plumber.R")
  # errors when neither dir is empty and file is not given
  expect_error(plumb(dir=""), regexp="You must specify either a file or directory*")
  # reads from working dir if no args
  expect_error(plumb(), regexp="File does not exist: ./plumber.R")
  # errors when both dir and file are given
  expect_error(plumb(file="files/endpoints.R", dir="files"), regexp="You must set either the file or the directory parameter, not both")
})

test_that("plumb() a dir leverages `entrypoint.R`", {
  expect_null(plumber:::.globals$serializers$fake, "This just that your Plumber environment is dirty. Restart your R session.")

  r <- plumb(dir = 'files/entrypoint/')
  expect_equal(length(r$endpoints), 1)
  expect_equal(length(r$endpoints[[1]]), 1)

  # A global serializer was added by entrypoint.R before parsing
  expect_true(!is.null(plumber:::.globals$serializers$fake))

  # Clean up after ourselves
  gl <- plumber:::.globals
  gl$serializers["fake"] <- NULL
})

test_that("bad `entrypoint.R`s throw", {
  expect_error(plumb(dir = 'files/entrypoint-bad/'), "runnable Plumber router")
})

test_that("Empty endpoints error", {
  expect_error(plumber$new("files/endpoints-empty.R"), regexp="No path specified")
})

test_that("The old roxygen-style comments work", {
  r <- plumber$new("files/endpoints-old.R")
  expect_equal(length(r$endpoints), 1)
  expect_equal(length(r$endpoints[[1]]), 4)
  expect_equal(r$endpoints[[1]][[1]]$exec(), 5)
  expect_equal(r$endpoints[[1]][[2]]$exec(), 10)
  expect_equal(r$endpoints[[1]][[3]]$exec(), 12)
  expect_equal(r$endpoints[[1]][[4]]$exec(), 14)
})

